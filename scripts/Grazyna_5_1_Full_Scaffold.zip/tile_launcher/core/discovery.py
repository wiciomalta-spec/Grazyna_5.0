from pathlib import Path
print('Auto discovery module')
