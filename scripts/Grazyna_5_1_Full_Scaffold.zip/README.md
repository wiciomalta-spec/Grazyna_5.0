# Grażyna 5.1 Full Scaffold

Rozszerzony szkielet projektu.
