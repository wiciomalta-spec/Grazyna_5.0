Map viewer, compare, checksums
