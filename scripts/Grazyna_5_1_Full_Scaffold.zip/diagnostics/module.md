DTC, Live Data, Kodowanie, Adaptacje
